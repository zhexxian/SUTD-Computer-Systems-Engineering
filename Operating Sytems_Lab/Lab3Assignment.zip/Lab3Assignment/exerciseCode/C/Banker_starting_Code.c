/**
 * CSE lab project 3 -- C version
 * 
**/

#include <stdio.h>
#include <stdlib.h>

int numberOfCustomers;
int numberOfResources;

int available[10];
int maximun[10][10];
int allocation[10][10];
int need[10][10];



void initBank(int resources[], int resourcesNumber, int customerNumber) {
	// TODO: set numberOfCustomers and numberOfResources
	

	// TODO: init available/maximum/allocation/need

}


void showState() {
	// print the current state with a tidy format
	printf("\nCurrent state: \n");
	printf("Available: \n");
	int idx = 0;
	for (idx = 0; idx < numberOfResources; idx++) {
		printf("%d ", available[idx]);
	}
	printf("\n");
	printf("\nMaximun: \n");
	for (idx = 0; idx < numberOfCustomers; idx++) {
		for(int idy = 0; idy < numberOfResources; idy++) {
			printf("%d ", maximun[idx][idy]);
		}
		printf("\n");		
	}
	printf("\nAllocation: \n");
	for (idx = 0; idx < numberOfCustomers; idx++) {
		for(int idy = 0; idy < numberOfResources; idy++) {
			printf("%d ", allocation[idx][idy]);
		}
		printf("\n");		
	}
	
	printf("\nNeed: \n");
	for (idx = 0; idx < numberOfCustomers; idx++) {
		for(int idy = 0; idy < numberOfResources; idy++) {
			printf("%d ", need[idx][idy]);
		}
		printf("\n");		
	}	
	printf("\n");
}


int addCustomer(int customerId, int maximunDemand[]) {
	// TODO: add customer, update maximum and need

}


int checkSafe(int customerId, int request[]) {
	// TODO: check if the new state is safety

}

int requestResources(int customerId, int request[]) {

	// deal with new request resources
	printf("\nRequest resource, customerId %d: [", customerId);
	int idx = 0;
	for(idx = 0; idx < numberOfResources-1; idx++) {
		printf("%d, ", request[idx]);
	}
	printf("%d]\n",request[numberOfResources-1]);

	// TODO: judge if request larger than need

	// TODO: judge if request larger than avaliable

	// TODO: judge if the new state is safe if grants this request (for question 2)

	// TODO: request is granted, update state

	

}


int releaseResources(int customerId, int release[]) {
	// TODO: deal with release (:For simplicity, we do not judge the release request, just update directly)
		
}





int main (int argc, const char * argv[]) 
{	// Test code for Question 1
	numberOfCustomers = 5;
	numberOfResources = 3;
	int resource[3] = {10, 5, 7};
	initBank(resource, sizeof(resource)/sizeof(int),numberOfCustomers);
	int maximunDemand[5][3] = {
		{7, 5, 3}, 
		{3, 2, 2}, 
		{9, 0, 2},
		{2, 2, 2},
		{4, 3, 3}
		};
	int idx = 0;
	for(idx = 0; idx < numberOfCustomers; idx++) {
		addCustomer(idx,maximunDemand[idx]);
	}
	
	int request[5][3] = {
		{0, 1, 0},
		{2, 0, 0},
		{3, 0, 2},
		{2, 1, 1},
		{0, 0, 2}
	};
   requestResources(0,request[0]);
   requestResources(1,request[1]);
   requestResources(2,request[2]);
   requestResources(3,request[3]);
   requestResources(4,request[4]);
   showState();

   // Test code for Question 2, please comment out the following part when test Question 1
   int newRequest1[3] = {1, 0, 2};
   requestResources(1, newRequest1);
   showState();
   int newRequest2[3] = {0, 2, 0};
   requestResources(0, newRequest2);
   showState();
   // End of test code for Question 2

}



