// package Week3;

public class BankImpl {
	private int numberOfCustomers;	// the number of customers
	private int numberOfResources;	// the number of resources

	private int[] available; 	// the available amount of each resource
	private int[][] maximum; 	// the maximum demand of each customer
	private int[][] allocation;	// the amount currently allocated
	private int[][] need;		// the remaining needs of each customer
	
	public BankImpl (int[] resources, int numberOfCustomers) {
		// TODO: set the number of resources

		// TODO: set the number of customers

		// TODO: set the value of bank resources to available

		// TODO: set the array size for maximum, allocation, and need

	}
	
	public int getNumberOfCustomers() {
		// TODO: return numberOfCustomers
		
	}

	public void addCustomer(int customerNumber, int[] maximumDemand) {
		// TODO: initialize the maximum, allocation, need for this customer
		
		// TODO: check if the customer's maximum demand exceeds bank's available resource

		// TODO: set value for maximum and need
		
	}

	public void getState() {
		// TODO: print available

		// TODO: print allocation

		// TODO: print max

		// TODO: print need

	}

	public synchronized boolean requestResources(int customerNumber, int[] request) {
		// print the request

		// TODO: check if request larger than need

		// TODO: check if request larger than available


		// TODO: check if the state is safe or not

		// TODO: if it is safe, allocate the resources to customer customerNumber 
		
		// TODO: return state

	}

	public synchronized void releaseResources(int customerNumber, int[] release) {
		// print the release

		// TODO: release the resources from customer customerNumber 

	}

	private synchronized boolean checkSafe(int customerNumber, int[] request) {
		// TODO: check if the state is safe
		// TODO: initialize a finish vector

		// TODO: copy the available matrix to temp_available
		// TODO: subtract request from temp_available
		// TODO: temporarily subtract request from need
		// TODO: temporarily add request to allocation

		// TODO: if customer request exceed maximum, return false

		// TODO: check if the Bank's algorithm can finish based on safety algorithm
		// (see P332, Section 7.5.3.1, Operating System Concepts with Java, Eighth Edition)
		// TODO: restore the value of need and allocation for the customer
		// TODO: go through the finish to see if all value is true
		// TODO: return state
	}
}