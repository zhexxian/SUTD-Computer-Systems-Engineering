import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class MergeSortThreaded2 {
	public static void main(String[] args) throws InterruptedException, FileNotFoundException  {
		// define thread number
		int NumOfThread = Integer.valueOf(args[1]);
		// read data from txt
		Scanner fileIn = new Scanner(new File(args[0]));
		ArrayList<Integer> array = new ArrayList<Integer>();
		while(fileIn.hasNextInt()){
			array.add(fileIn.nextInt());
		}
		fileIn.close();
		// TODO: partition the array into N part
		
		// start recording time
		long startTime = System.currentTimeMillis();
		// TODO: run MergeThread with N threads
		
		// TODO: merge the N sorted array
		
		// TODO: get the final sorted list
		
		// end recording time
		long endTime = System.currentTimeMillis();
		// show the time
		long runningTime = endTime - startTime;
		System.out.println("Running time is " + runningTime + " milliseconds");

		// TODO: print the sorted array value
		
		System.out.println("\nFinish sorting!");
	}

	// TODO: merge sortedLists into a full sorted list
	public static ArrayList<Integer> mergeArrays(ArrayList< ArrayList<Integer>> sortedLists) {
		// create sorted list, name as mergedList
		ArrayList<Integer> mergedList = new ArrayList<Integer>();
		// TODO: merge the multiple sorted arrays
		return mergedList;
	}

}


// extend thread
class MergeThread extends Thread {
	private ArrayList<Integer> list;

	public ArrayList<Integer> getInternal() {
		return list;
	}

	// TODO: implement merge sort here, recursive algorithm
	public void mergeSort(ArrayList<Integer> array) {
		
	}


	MergeThread(ArrayList<Integer> array) {
		list = array;
	}

	public void run() {
		// called by object.start()
		mergeSort(list);
	}
}

