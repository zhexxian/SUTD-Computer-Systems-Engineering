import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class MultiThread {
	static 
	public static void main(String[] args) throws InterruptedException, FileNotFoundException {
		// define thread number
		int NumOfThread = Integer.valueOf(args[1]);
		// read data from txt
		Scanner fileIn = new Scanner(new File(args[0]));
		ArrayList<Integer> array = new ArrayList<Integer>();
		while(fileIn.hasNextInt()){
			array.add(fileIn.nextInt());
		}
		fileIn.close();
		// TODO: partition the array list into N part

		// TODO: run SimpleThread with N threads

		// TODO: get the N max values
		
		// TODO: show the N max values

		// TODO: get the max value from N max values

		// TODO: show the max value

	}
}

//extend thread
class SimpleThread extends Thread {
	private ArrayList<Integer> list;
	private int max;

	public int getMax() {
		return max;
	}

	SimpleThread(ArrayList<Integer> array) {
		list = array;
	}

	public void run() {
		// TODO: implement actions here
	}
}